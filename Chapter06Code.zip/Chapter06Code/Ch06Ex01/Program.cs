﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch06Ex01
{
    class Program
    {
        static void Write()
        {
            Console.WriteLine("Text output from function.");
        }

        static void Main(string[] args)
        {
            Write();
            Console.ReadKey();
        }
    }
}
